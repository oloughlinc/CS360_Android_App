package edu.snhu.craigo_eventapp;

public enum LoginStatus {
    LOGIN_OK,
    LOGIN_NO_USER,
    LOGIN_BAD_PASSWORD,
}
