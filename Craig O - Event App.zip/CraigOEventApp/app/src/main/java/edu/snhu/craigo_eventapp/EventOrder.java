package edu.snhu.craigo_eventapp;

public enum EventOrder {
    byDate,
    byPriority
}
